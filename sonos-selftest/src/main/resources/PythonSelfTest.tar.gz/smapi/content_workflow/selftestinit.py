import sys
import os
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos_unittest2-1.1.0.dev_r262410-py2.7.egg".format(os.sep)))
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos_elementtree-1.1.0.dev_r262410-py2.7.egg".format(os.sep)))
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos_simplejson-1.1.0.dev_r262410-py2.7.egg".format(os.sep)))
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos_suds-1.1.0.dev_r262410-py2.7.egg".format(os.sep)))
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos-1.1.0.dev_r300235-py2.7.egg".format(os.sep)))
sys.path.insert(0, os.path.normpath("..{0}..{0}sonos_sslyze-1.1.0.dev_r293552-py2.7.egg".format(os.sep)))
